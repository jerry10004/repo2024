$(document).ready(function() {

  var menu = false;
  //모바일 크기에서 메뉴 버튼 클릭시 애니메이션
  $("#menu").click(function(event) {
    menu = !menu;
    if(menu) {
      $('#hidemenu').slideDown('slow');
    } else {
      $('#hidemenu').slideUp('slow');
    }
    event.preventDefault();

  });

  // 메인 홈 페이지 텍스트
  $('#homeText').text(homeText);

  //
  for (var i = 0; i < data.length; i++) {
    if ((data[i].id.substring(7) == 11)){
      var newSection =
      `<section id="${data[i].id}" class="lab" style="background:${data[i].backgroundColor}">
        <div class="lab-content-back" style="background-image: url(assets/img/${data[i].id.substring(7)}.jpg);">
          <div class="lab-content" style="padding-bottom: 80px">
            <div class="lab-poster">
              <a class="fancybox" href="${data[i].posterUrl}" target="_blank"><img src="${data[i].posterUrl}" alt="arise"/></a>
            </div>
            <div class="lab-description">
              <h2>${data[i].name}</h2>
              <h3>${data[i].professor}</h3>
              <h6>${data[i].email}</h6>
              <p>${data[i].content}</p>
              <h4>2019's Projects</h4>
              <h5>${data[i].projects}</h5>
            </div>
          </div>
      </section>`
    } else {
      var newSection =
      `<section id="${data[i].id}" class="lab" style="background:${data[i].backgroundColor}">
        <div class="lab-content-back" style="background-image: url(assets/img/${data[i].id.substring(7)}.jpg);">
          <div class="lab-content">
            <div class="lab-poster">
              <a class="fancybox" href="${data[i].posterUrl}" target="_blank"><img src="${data[i].posterUrl}"  alt="arise"/></a>
            </div>
            <div class="lab-description">
              <h2>${data[i].name}</h2>
              <h3>${data[i].professor}</h3>
              <h6>${data[i].email}<h6>
              <p>${data[i].content}</p>
              <h4>2019's Projects</h4>
              <h5>${data[i].projects}</h5>

            </div>
          </div>
          </div>
      </section>`
    }
    $('body').append(newSection);
  }
  var footer =
  `<footer>
    <div class="left">
      <img src="assets/img/S-Labs.png">
    </div>
    <div class="center">
      <div class="copyright">Copyright &copy; 2019</div>
      <div>한동대학교 전산전자공학부 All Rights Reserved.</div>
    </div>
    <div class="right">
      <div class="developer">
        <span>Developer</span> 강예찬 최선웅
      </div>
      <div class="designer">
        <span>Designer</span> 윤은진
      </div>
    </div>
  </footer> `

  $('body').append(footer);
  // 사이드 네비게이션바 목록 불러오기
  $('#hidelst').append(`<li>
                        <a href="#${home}">
                        <div ></div>
                        <span class="sidenav-item">Home</span>
                        </a>
                        </li>`);
  for (var i = 0; i < data.length; i++) {
    $('div.sidenav').append(`<a href="#${data[i].id}">
                              <div class="circle"></div>
                              <span class="sidenav-item">${data[i].name}</span>
                              </a>`);
    $('#hidelst').append(`<li><a href="#${data[i].id}">
                          <div ></div>
                          <span class="sidenav-item">${data[i].name}</span>
                          </a>
                          </li>`);
  }

  $('#hidemenu').on('click', 'a', function(event) {
    menu = !menu;
    $('#hidemenu').slideUp('slow');

  })

  // 섹션 이동에 따른Active한 사이드 네비게이션바

  let mainNavLinks = document.querySelectorAll(".sidenav-container .sidenav a");

  window.addEventListener("scroll", event => {
    let fromTop = window.scrollY;

    mainNavLinks.forEach(link => {
      let section = document.querySelector(link.hash);
      if (
        section.offsetTop <= fromTop + 400 &&
        fromTop + 400 < section.offsetTop + section.offsetHeight
      ) {
        link.querySelector('.circle').classList.add("dot");
        link.querySelector('.sidenav-item').classList.add("active");
      } else {
        link.querySelector('.circle').classList.remove("dot");
        link.querySelector('.sidenav-item').classList.remove("active");
      }
    });
  });

  //Top button
  window.addEventListener("scroll", event => {
      if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
      document.getElementById("topBtn").style.display = "block";
    } else {
      document.getElementById("topBtn").style.display = "none";
    }
  });

  $("#topBtn").click(function() {
    document.body.scrollTop = 0;
    document.documentElement.scrollTop = 0;
  })


})
