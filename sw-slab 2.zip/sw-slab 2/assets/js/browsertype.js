var agent = navigator.userAgent.toLowerCase();
var browser;
if (agent.indexOf('msie') > -1) {
  browser = 'ie ' + agent.match(/msie (\d+)/)[1]
}
else if(agent.indexOf('trident') > -1) {
  browser = 'ie 11'
}
else if(agent.indexOf('edge') > -1) {
  browser = 'edge'
}
else if(agent.indexOf('firefox') > -1) {
  browser = 'firefox'
}
else if(agent.indexOf('opr') > -1) {
  browser = 'opera'
}
else if(agent.indexOf('chrome') > -1) {
  browser = 'chrome'
}
else if(agent.indexOf('safari') > -1) {
  browser = 'safari'
}
var browsertype = browser.split(' ');
browsertype = browsertype[0];
if(browsertype == "ie"){
  alert('Internet Explorer에서는 사용이 제한됩니다.\n다른 브라우저를 이용해 주세요.');
  history.back();
}
