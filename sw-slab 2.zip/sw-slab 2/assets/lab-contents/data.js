// 메인 페이지 설명 글
var homeText = `한동대 전산전자학부는 미래지향적 사고를 갖추고, 지속적으로 성장하는 IT분야의 리더가 되기
위하여 전공지식 뿐만 아니라 실용적 전문성, 국제화 역량 및 기독교정신을 가진
소프트웨어 및 임베디드 시스템 전문가와 급속한 변화에 유연하게 대처할 뿐만아니라
향후 전자공학 및 관련분야의 핵심인재로 성장가능한 자기계발 능력을 기르고,
기독교적 직업윤리와 의사소통능력을 갖춘 인재를 양성하고자 합니다.`

// 각 랩실 별 데이터
var data = [
  {
    id: "section01",
    name: "ARISE Lab",
    professor: "홍신 교수님",
    backgroundColor: "white",
    posterUrl: "assets/img/lab-poster/arise.jpg",
    content: `We study the phenomena and the principles in software developments,<br/>
    and develop tools and methodologies to assist men to write reliable, secure, and safe software.<br/>
    We aim to advance software testing and analysis techniques including dynamic/static bug findings, automated test generations and automated debugging.`,
    projects: `<i class="fa-li fa fa-check"></i>Static analysis checker for detecting Python web vulnerability<br/>
    <i class="fa-li fa fa-check"></i>Automated test generation framework for embedded systems<br/>
    <i class="fa-li fa fa-check"></i>Web-based programming education platform<br/>
    <i class="fa-li fa fa-check"></i>Developing Automated Software Test Generation Techniques Using Data-driven Analyses<br/>
    <i class="fa-li fa fa-check"></i>Intelligent Automation Techniques for Fullstack Software Debugging, Next-Generation Information Computing Development Program<br/>
    <i class="fa-li fa fa-check"></i>Systematic Evaluation of Test Case Effectiveness
    `,
    email: "hongshin@handong.edu",
    web: "arise.handong.edu"
  },
  {
    id: "section02",
    name: "BCI Lab",
    professor: "안민규 교수님",
    backgroundColor: "#6399cf",
    posterUrl: "assets/img/lab-poster/2020bci.png",
    content: `BCI Lab에서는 공학/생명/심리 등 다양한 전공을 가진 학생들이 모여<br/>
    기계학습기반 생체신호처리, 디지털헬스케어, BCI 어플리케이션 개발, 뇌질환 연구 등을 수행하고 있습니다.<br/>
    랩원 소개 등 더 자세한 정보는 랩 홈페이지 (https://bcilab.handong.edu/) 에 안내되어 있습니다.
    `,
    projects: `<i class="fa-li fa fa-check"></i>BCI 드론 제어<br/>
    <i class="fa-li fa fa-check"></i>이상운동증 정량화 앱 개발<br/>
    <i class="fa-li fa fa-check"></i>MRI 뇌영상 분석<br/>
    <i class="fa-li fa fa-check"></i>우울증 개선을 위한 뉴로피드백 게임 개발<br/>
    <i class="fa-li fa fa-check"></i>BCI 게임 개발`,
    email: "minkyuahn@handong.edu",
    web: "https://bcilab.handong.edu/"
  },
  {
    id: "section03",
    name: "CGV Lab",
    professor: "황성수 교수님",
    backgroundColor: "#dde4ec",
    posterUrl: "assets/img/lab-poster/cgv.jpg",
    content: `CGV Lab은 Computer Graphics & Vision의 줄임말 입니다.<br/>
    저희 S-Lab은 영상처리와 증강현실, VSLAM, 3D Reconstruction & Compression, 자율주행차량 등 컴퓨터 그래픽과 비전을 활용한 다양한 응용분야를 연구하고 있습니다.<br/>
    그 예로 현재까지 큐브를 활용한 증강현실, 실내지도를 활용한 드론 조작, 빔프로젝터 터치 게임, 영상기반 스트레스 측정, 베이다스 산학협력 프로젝트로 차량 하방영상 자동 생성, 마커기반 멀티유저 증강현실 게임 등 과 같은 다양한 프로젝트를 수행하였습니다. `,
    projects: `<i class="fa-li fa fa-check"></i>다중 시점 영상을 이용한 3D Reconstruction<br/>
    <i class="fa-li fa fa-check"></i>3D reflectance estimation<br/>
    <i class="fa-li fa fa-check"></i>다중 사용자 환경 AR 시스템<br/>
    <i class="fa-li fa fa-check"></i>어안렌즈용 Feature matching<br/>
    <i class="fa-li fa fa-check"></i>Initialization robust slam Depth estimation<br/>
    <i class="fa-li fa fa-check"></i>Illumination robust place recognition`,
    email: "sshwang@handong.edu",
    web: "cgvlab.handong.edu"
  },
  {
    id: "section04",
    name: "Deep Learning Lab",
    professor: "김인중 교수님",
    backgroundColor: "#345db2",
    posterUrl: "assets/img/lab-poster/deep.jpg",
    content: `DLLAB은 딥러닝을 통해 자연어처리, 산업데이터예측, 컴퓨터비전, 음성합성 등의 다양한 문제를 해결하고 있으며 포스코, 엔씨소프트, 스켈터랩스, 딥바이오 등의 기업과 산학연계연구를 진행하고 있습니다.<br/>
    S-LAB 소속 학생들은 본인 성취도에 따라 딥러닝 스터디 (초급/중급/고급)를 선택하여 구성원들과 함께 공부하고 있습니다.`,
    projects: `<i class="fa-li fa fa-check"></i>NC Soft: GAN을 이용한 음성 합성 스타일 모델링 연구<br/>
    <i class="fa-li fa fa-check"></i>머신러닝 학습 및 추론 엔진 간 연동을 위한 데이터 모델 어뎁터 모듈 구현(ETRI)<br/>
    <i class="fa-li fa fa-check"></i>모바일 환경에서 영상을 인식하기 위한 딥러닝 엔진 개발<br/>
    <i class="fa-li fa fa-check"></i>딥러닝을 이용한 영상인식 엔진 개발<br/>
    <i class="fa-li fa fa-check"></i>자연어 대화 처리를 위한 기반 기술 연구<br/>
    <i class="fa-li fa fa-check"></i>딥러닝 오픈소스 프레임워크 WICWIU 구현`,
    email: "ijkim@handong.edu",
    web: "deephandong.github.io"
  },
  {
    id: "section05",
    name: "HAIL",
    professor: "홍참길 교수님",
    backgroundColor: "white",
    posterUrl: "assets/img/lab-poster/hail.jpg",
    content: `HAIL은 머신러닝/인공지능 기술을 개발하고, 다양한 도메인에 적용하는 활동을 하는 학술연구 그룹 입니다. 우리는 컴퓨터 과학의 관점에서 데이터를 바라보고, 문제를 해결하고자 합니다. 피조물이 창조한 피조물인 컴퓨터 안에서 하나님의 창조 원리가 동일하게 작용하는 것을 깨닫고, 나아가 그 원리들을 지렛대 삼아 인간을 이롭게 할 수 있는 활동들을 실천해 나가고자 합니다. 우리 연구실은 structured prediction, outlier detection, time-series modeling, natural language understanding 등의 세부 주제에 관심이 많으며, 이들 기술을 의료, 에너지, 문헌, 금융, 영상 등 다양한 형태와 도메인의 데이터에 적용하는 활동을 추진하고 있습니다.`,
    projects: `<i class="fa-li fa fa-check"></i>머신러닝/인공지능 프레임워크 개발<br/>
    <i class="fa-li fa fa-check"></i>의료 데이터 분석 및 예측<br/>
    <i class="fa-li fa fa-check"></i>통일 빅데이터센터 검색엔진 개발<br/>
    <i class="fa-li fa fa-check"></i>Fiji 햇빛 지도 개발<br/>
    <i class="fa-li fa fa-check"></i>감시 카메라 영상 자동 축약 기술 개발<br/>
    <i class="fa-li fa fa-check"></i>Kaggle, Kagglers: 경진대회 및 해카톤 참여<br/>`,
    email: "charmgil@handong.edu",
    web: ""
  },
  {
    id: "section06",
    name: "ISEL",
    professor: "남재창 교수님",
    backgroundColor: "#6399cf",
    posterUrl: "assets/img/lab-poster/isel.jpg",
    content: `ISEL(Intelligent Software Engineering Lab, 지능형 소프트웨어 연구실)에서는 소프트웨어 공학의 다양한 문제들, 특히 디버깅 활동과 관련된 문제들을 해결하는데 관심이 많습니다.
    소프트웨어 개발자를 돕고 그 결과로 안전하고 신뢰도가 높은 소프트웨어가 출시될 수 있다면, 다양한 소프트웨어 제품과 서비스를 사용하는 모든 사람들을 본질적으로 도울 것이라 기대하고 있습니다.<br/>
    주요 접근 방법은 머신/딥러닝 및 MSR(Mining Software Repositories, 마이닝 소프트웨어 저장소) 기법을 활용하여 현재까지 GitHub 프로젝트 수집 도구, 버그 정보 수집 도구, 소프트웨어 메트릭 수집 도구(코드 메트릭, 프로세스 메트릭, NGLP, etc.) 와 같은 버그 예측을 위한 다양한 도구들도 구현하는 프로젝트들을 진행하였습니다. <br/>
    현재 아이즐(ISEL)에는 2명의 대학원생과 10명의 학부 학생들이 다양한 디버깅 기술을 연구하며 도구를 개발하고 있습니다. 개발자들을 돕고 섬길 수 있는 새로운 기술을 개발하고 싶은 학생들은 언제든지 연락 바랍니다.`,
    projects: `<i class="fa-li fa fa-check"></i>개선된 자동 버그 수정 기술 제안 및 도구 개발<br/>
    <i class="fa-li fa fa-check"></i>개발자 프로파일 기반의 소프트웨어 결함 예측<br/>
    <i class="fa-li fa fa-check"></i>자바 과제 자동채점 엔진 개발<br/>
    <i class="fa-li fa fa-check"></i>버그 패치 추천<br/>
    <i class="fa-li fa fa-check"></i>버그 예측을 위한 새로운 메트릭 발굴`,
    email: "jcnam@handong.edu",
    web: ""
  },
  {
    id: "section07",
    name: "MCNL",
    professor: "고윤민 교수님",
    backgroundColor: "#dde4ec",
    posterUrl: "assets/img/lab-poster/mcnl.jpg",
    content: `MCNL (Mobile Computing and Networking Lab)에서는
혁신적인 미디어 서비스를 위한 모바일 컴퓨팅 기술과 네트워크
기술에 대해 연구합니다. MCNL에서 연구하는 기술들은 현재의
스마트폰 기술과 현재의 모바일 네트워크 기술들을 뛰어 넘어,
보다 혁신적이고 보다 사람을 위한 기술이 되는 것을 목적으로
합니다. 그리고 이곳에서 만들어지는 기술들이 이 세상을
변화시키기 위한 작은 디딤돌이 되길 소망합니다. 이러한 일에
관심이 있고 열정이 있는 학생들은 언제든지 연락 바랍니다. `,
    projects: `<i class="fa-li fa fa-check"></i>MPEG-DASH (Dynamic Adaptive Streaming over HTTP) 기반
Augmented Reality 스트리밍 시스템 개발<br/>
    <i class="fa-li fa fa-check"></i>Augmented Reality 서비스를 위한 Mobile Edge Computing
기술 개발<br/>
    <i class="fa-li fa fa-check"></i>Raspberry Pi와 Software Defined Networking 기술을 활용한
Mesh WiFi 네트워크 구축<br/>`,
    email: "yunmin@handong.edu",
    web: " https://sites.google.com/handong.edu/mcnl"
  },
  {
    id: "section08",
    name: "MI-Lab",
    professor: "최희열 교수님",
    posterUrl: "assets/img/lab-poster/milab.jpg",
    backgroundColor: "#345db2",
    content: `MI Lab에는 지도 교수님이신 최희열 교수님과, 1명의 연구원, 4명의 대학원생 그리고 11명의 학부생들이 함께 소속되어 있습니다.<br/>
대학원생들은 Deep learning와 Reinforcement Learning에 관련된 다양한 연구 주제들을 가지고 함께 연구하고 있고 또한 교수님께서 진행하고 계신 여러 과제들에 함께 참여하고 있습니다.<br/>
학부생들은 주로 Deep learning 관련 캡스톤 또는 공학 프로젝트 기획을 진행하고 있는 학생들과 Deep Learning과 머신러닝에 관심을 가지고 S-Lab으로 참여하는 학생들도 있습니다.<br/>`,
    projects: `<i class="fa-li fa fa-check"></i>인공지능 기반 가상 네트워크 관리기술 개발<br/>
    <i class="fa-li fa fa-check"></i>VADAS 자율주행/자율주차 강화학습 모델 개발<br/>
    <i class="fa-li fa fa-check"></i>순환신경망 기반 음향압축 기술 연구 (2020.6~2020.11)`,
    email: "hchoi@handong.edu",
    web: ""
  },
  {
    id: "section09",
    name: "MMIC Lab",
    professor: "김영식 교수님",
    backgroundColor: "white",
    posterUrl: "assets/img/lab-poster/mmic.jpg",
    content: `MMIC Lab(Monolithic Microwave Integrated Circuit Laboratory)은 유/무선 통신에 활용되는 고속·저전력 회로에 대한 연구를 하는 곳입니다.<br/>
    아날로그·디지털·RF등 여러 분야에 대한 회로를 설계하고 제작하며, 제작된 칩들을 테스트하는 다양한 장비들을 갖추고 있습니다.<br/>
    김영식 교수님의 지도 아래 4명의 대학원생과 8명의 학부생이 소속되어 있으며, 뉴턴홀 317호에 연구실이 있습니다.`,
    projects: `<i class="fa-li fa fa-check"></i>Wakeup Receiver 및 Analog to Digital Converter Chip Design<br/>
    <i class="fa-li fa fa-check"></i>다중 카메라 인터페이스 개발<br/>
    <i class="fa-li fa fa-check"></i>자율주행을 위한 영상인식 및 주행 제어 플렛폼 개발<br/>
    <i class="fa-li fa fa-check"></i>해양 관측 레이더용 데이터 수집 및 처리 장치 개발<br/>
    <i class="fa-li fa fa-check"></i>Adaptive Echo-canceling Headphone Design<br/>
    <i class="fa-li fa fa-check"></i>Pipeline Inspection Robot`,
    email: "young@handong.edu",
    web: ""
  },
  {
    id: "section10",
    name: "Nano Seed Lab",
    professor: "박영춘 교수님",
    backgroundColor: "#6399cf",
    posterUrl: "assets/img/lab-poster/NSL.png",
    content: `Nano Seed Lab은 TiO2의 Hydrophilicity 특성을 분석하고 이에 대한 applications을 연구하고 있습니다.
아울러, VOCs(Volatile Organic Compounds)를 검출하는 Gas sensor 개발에 매진하고 있습니다. `,
    projects: `<i class="fa-li fa fa-check"></i>이산화 티타늄 박막 연구<br/>
    <i class="fa-li fa fa-check"></i>VOCs 검출 Gas sensor<br/>
    <i class="fa-li fa fa-check"></i>장 모방 체외 분석/진단 플랫폼 개발<br/>`,
    email: "ycpark@handong.edu",
    web: ""
  },
  {
    id: "section11",
    name: "SIRLab",
    professor: "이원형 교수님",
    backgroundColor: "#dde4ec",
    posterUrl: "assets/img/lab-poster/SIRLAB.jpg",
    content: `우리 랩은 사람과 상호작용이 가능한 로봇및 가상현실 아바타를 연구개발하고 있습니다.
    이러한 기술은 센서 등을 통한 데이터 입력처리와 이를 바탕으로 하는 시스템의 의사 결정,
    그리고 사람에게 다시 로봇(및 가상 에이전트)의 행동을 표현하는 단계까지 폭 넓은 지식과 경험을 필요로 합니다.
    따라서, Harware뿐 아니라 Software와 System Integration, Software간의 유기적인 통신,
    그리고 User Experience 등 사용자에 대한 이해까지 다양한 공부를 진행하게 됩니다. 실제 움직이고 사람과 소통하는 로봇을 만들다 보니,
    직접 동작하는 결과물을 확인할 때 높은 성취감을 얻을 수 있습니다.
    해당 기술은 이후 꼭 로봇 분야가 아니더라도 공학과 관련하여 다양한 분야에서 사용되고 있기에 이후 진로를 탐색하기에 좋습니다.`,
    projects: `<i class="fa-li fa fa-check"></i>ITDA: 마음을 이어주는 로봇 서비스<br/>
    <i class="fa-li fa fa-check"></i>로봇 팔 원격 조종 방법 연구 + VR활용<br/>
    <i class="fa-li fa fa-check"></i>가상환경에서 3D 아바타 디자인 및 상호작용 개발<br/>
    <i class="fa-li fa fa-check"></i>양육 상담 서비스 로봇의 추천 알고리즘 개발<br/>`,
    email: "whlee@handong.edu",
    web: " https://sites.google.com/handong.edu/sirlab/home"
  },
  {
    id: "section12",
    name: "SW Factory Lab",
    professor: "조성배 교수님",
    backgroundColor: "#345db2",
    posterUrl: "assets/img/lab-poster/SWFactory.png",
    content: `저희 랩은 조성배 교수님의 지도 하에 학업과 연구를 바탕으로 창업 아이디어를 아이템하거나, 서비스 상용화 혹은 실제 창업을 목표로 도전하는 사람들이 모여 함께 공부하는 랩 입니다.
    현재 모바일 앱 개발, ml kit를 활용한 서비스 개발, 게임 개발 등 여러 분야에 관하여 공부하고, 개발을 진행하는 중입니다.
    저희 랩은 본인이 가지고 있는 아이디어를 공유, 검토하고 개발을 희망 하는 학생들로 이루어져있습니다.`,
    projects: `<i class="fa-li fa fa-check"></i>2019 대한민국 키즈 디자인 창업아이디어 경진대회 대상 수상 ((재)경북테크노파크 주최)<br/>
    <i class="fa-li fa fa-check"></i>2019소셜벤처 경연대회 대학생 아이디어부문 경상권 권역 1위<br/>
    <i class="fa-li fa fa-check"></i>대국민 ICT 아이디어 R&D 기획 공모전 대상(과학기술정보통신부 장관상)<br/>
    <i class="fa-li fa fa-check"></i>2019 소셜벤처 경연대회 전국 대학생 아이디어부문 1위 후원사상(LG화학 창의인재상)<br/>
    <i class="fa-li fa fa-check"></i>제 7회 문화데이터 활용 경진대회 최우수상(국립중앙박물관장상)<br/>
    <i class="fa-li fa fa-check"></i>2019 소프트웨어 융합 경진대회 우수상<br/>
    <i class="fa-li fa fa-check"></i>K-startup 2020 예비창업패키지 선정<br/>
    <i class="fa-li fa fa-check"></i>2020년도 공공기술기반 시장연계 창업탐색 지원사업(I-Corps) 선정<br/>
    <i class="fa-li fa fa-check"></i>제 8회 G-Star 대학생 창업경진대회 장려상(경북창조경제센터장상)<br/>
    <i class="fa-li fa fa-check"></i>2021 G-Star 대학생 창업경진대회 수상 (총 2팀)<br/>
    <i class="fa-li fa fa-check"></i>2020-21 예비창업패키지 수상(총 5팀)<br/>
    <i class="fa-li fa fa-check"></i>2020-21 I-corps ¤¤기술기반 t장연계 창업탐색 지원사업 선=(총 4팀)<br/>
    <i class="fa-li fa fa-check"></i>수도권 최대 규V 종합 게임쇼 PlayX4 2021 인디 분야 선정<br/>
    <i class="fa-li fa fa-check"></i>2020 SW 스타트업 창업 챌린지 ¤V전 일반리그, 예비창업패키지리그 2팀 수상<br/>`,
    email: "sungbaejo@handong.edu",
    web: ""
  },
  {
    id: "section13",
    name: "WALAB",
    professor: "김광 & 장소연 교수님",
    backgroundColor: "white",
    posterUrl: "assets/img/lab-poster/WALAB.jpg",
    content: `WALAB은 Web and App Lab의 줄임말 입니다. 저희 S-Lab은 Web, App 개발 연구를 주로 진행하고 있으며 그 외에도 사물인터넷, 무선통신 등을 활용한 다양한 Web, App 개발 방법에 관심을 가지고 있습니다.`,
    projects: `<i class="fa-li fa fa-check"></i>근접 네트워크 자원 활용을 위한 플랫폼 개발<br/>
    <i class="fa-li fa fa-check"></i>LearnTube: Youtube 영상을 활용한 학습관리 시스템 <br/>
    <i class="fa-li fa fa-check"></i>CSEE 온라인 신청 통합 서비스 <br/>
    <i class="fa-li fa fa-check"></i>무선태그를 활용한 어린이 통학, 야외활동 안전지원 서비스  <br/>
    <i class="fa-li fa fa-check"></i>LearnTube2: Youtube 기반의 학습지원 서비스 고도화 <br/>
    <i class="fa-li fa fa-check"></i>SW전공자를 위한 포트폴리오 관리 시스템 <br/>`,
    email: "kkim@handong.edu",
    web: ""
  },
  {
    id: "section14",
    name: "스마트카 랩",
    professor: "이강, 황성수, 김영식 교수님",
    backgroundColor: "#6399cf",
    posterUrl: "assets/img/lab-poster/110.jpg",
    content: `이강,황성수,김영식 교수님이 지도해주시는 자율주행-머신러닝 랩입니다.<br/>
    저희는 1/10 전기자동차를 이용한 자율주행을 연구하고 있습니다.<br/>
    ROS환경에서 영상정보를 기반으로 차선인식, 차량인식, 보행자인식 등을 영상 처리나 머신 러닝을 통해 정보를 판단하여 원활한 자율주행을 할 수 있도록 속도및 조향을 제어하는 것을 목표로 합니다.<br/>
    그 외 Ridar 같은 센서를 이용한 제어도 목표로 하고 있습니다.
    연구를 통해 성능을 개선하여 자율주행 자동차 대회 우승을 목표로 하고 있습니다.`,
    projects: `<i class="fa-li fa fa-check"></i>머신러닝을 통한 다양한 object인식 및 제어<br/>
    <i class="fa-li fa fa-check"></i>차선 변경 알고리즘 개발<br/>
    <i class="fa-li fa fa-check"></i>다양한 환경 변수로부터 제어 및 주행 최적화`,
    email: "yk@handong.edu",
    web: ""
  },
  {
    id: "section15",
    name: "지능형 시스템 Lab",
    professor: "김호준 교수님",
    backgroundColor: "#dde4ec",
    posterUrl: "assets/img/lab-poster/xRay.jpg",
    content: `저희 S-Lab은 지능형 시스템 Lab에서는 영상처리와 인공지능 기술에 관한 연구를 수행합니다.<br/>
    세부적으로 의료영상 처리, 딥러닝 기법, 응용 소프트웨어 개발 등의 주제를 다루며 이에 대한 기반 지식을 공부하고<br/>
    논문 연구, 시스템 개발 연구, 산학협력프로젝트, 공학프로젝트기획 및 캡스톤연구를 수행하고 있습니다.`,
    projects: `<i class="fa-li fa fa-check"></i>X-ray 영상의 산란선 개선 소프트웨어 개발<br/>
    <i class="fa-li fa fa-check"></i>Grid Artifacts suppression을 위한 machine learning 기법 연구<br/>
    <i class="fa-li fa fa-check"></i>흉부 X-ray 영상에서 Bone Suppression을 위한 소프트웨어 개발`,
    email: "hjkim@handong.edu",
    web: ""
  },
]
