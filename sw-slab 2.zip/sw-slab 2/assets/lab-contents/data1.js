// 메인 페이지 설명 글
var homeText = `저희 학부에서는 미래지향적 사고를 갖추고, 지속적으로 성장하는 IT분야의 리더가 되기
위하여 전공지식 뿐만 아니라 실용적 전문성, 국제화 역량 및 기독교정신을 가진
소프트웨어 및 임베디드 시스템 전문가와 급속한 변화에 유연하게 대처할 뿐만아니라
향후 전자공학 및 관련분야의 핵심인재로 성장가능한 자기계발 능력을 기르고,
기독교적 직업윤리와 의사소통능력을 갖춘 인재를 양성하고자 합니다.`

// 각 랩실 별 데이터
var data = [
  {
    id: "section01",
    name: "ARISE Lab",
    professor: "홍신 교수님",
    backgroundColor: "white",
    posterUrl: "assets/img/lab-poster/arise.jpg",
    content: `Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
    Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
    Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.
    Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.`,
    projects: `<i class="fa-li fa fa-check"></i> -`,
    email: "hongshin@handong.edu",
    web: ""
  },
  {
    id: "section02",
    name: "BCI Lab",
    professor: "안민규 교수님",
    backgroundColor: "#6399cf",
    posterUrl: "assets/img/lab-poster/bciLab.jpg",
    content: `BCI Lab에서는 공학/생명/심리 등 다양한 전공을 가진 학생들이 모여<br/>
    기계학습기반 생체신호처리, 디지털헬스케어, BCI 어플리케이션 개발, 뇌질환 연구 등을 수행하고 있습니다.
    `,
    projects: `<i class="fa-li fa fa-check"></i>BCI 드론 제어<br/>
    <i class="fa-li fa fa-check"></i>이상운동증 정량화 앱 개발<br/>
    <i class="fa-li fa fa-check"></i>MRI 뇌영상 분석<br/>
    <i class="fa-li fa fa-check"></i>우울증 개선을 위한 뉴로피드백 게임 개발<br/>
    <i class="fa-li fa fa-check"></i>BCI 게임 개발`,
    email: "minkyuahn@handong.edu",
    web: "https://bcilab.handong.edu/home",
    posterUrl: "assets/img/lab-poster/bci.jpg"
  },
  {
    id: "section03",
    name: "CGV Lab",
    professor: "황성수 교수님",
    backgroundColor: "#dde4ec",
    posterUrl: "assets/img/lab-poster/cgv.jpg",
    content: `CGV Lab은 Computer Graphics & Vision의 줄임말 입니다.<br/>
    저희 S-Lab은 영상처리와 증강현실, VSLAM, 3D Reconstruction & Compression, 자율주행차량 등 컴퓨터 그래픽과 비전을 활용한 다양한 응용분야를 연구하고 있습니다.<br/>
    그 예로 현재까지 큐브를 활용한 증강현실, 실내지도를 활용한 드론 조작, 빔프로젝터 터치 게임, 영상기반 스트레스 측정, 베이다스 산학협력 프로젝트로 차량 하방영상 자동 생성, 마커기반 멀티유저 증강현실 게임 등 과 같은 다양한 프로젝트를 수행하였습니다. `,
    projects: `<i class="fa-li fa fa-check"></i>다중 시점 영상을 이용한 3D Reconstruction<br/>
    <i class="fa-li fa fa-check"></i>3D reflectance estimation<br/>
    <i class="fa-li fa fa-check"></i>다중 사용자 환경 AR 시스템<br/>
    <i class="fa-li fa fa-check"></i>어안렌즈용 Feature matching<br/>
    <i class="fa-li fa fa-check"></i>Initialization robust slam Depth estimation<br/>
    <i class="fa-li fa fa-check"></i>Illumination robust place recognition`,
    email: "sshwang@handong.edu",
    web: "cgvlab.handong.edu"
  },
  {
    id: "section04",
    name: "Deep Learning Lab",
    professor: "김인중 교수님",
    backgroundColor: "#345db2",
    posterUrl: "assets/img/lab-poster/deep.jpg",
    content: `DLLAB은 딥러닝을 통해 자연어처리, 산업데이터예측, 컴퓨터비전, 음성합성 등의 다양한 문제를 해결하고 있으며 포스코, 엔씨소프트, 스켈터랩스, 딥바이오 등의 기업과 산학연계연구를 진행하고 있습니다.<br/>
    S-LAB 소속 학생들은 본인 성취도에 따라 딥러닝 스터디 (초급/중급/고급)를 선택하여 구성원들과 함께 공부하고 있습니다.`,
    projects: `<i class="fa-li fa fa-check"></i>NC Soft: GAN을 이용한 음성 합성 스타일 모델링 연구<br/>
    <i class="fa-li fa fa-check"></i>온디바이스 few-shot learning 지원 신경망 모델 및 학습 기법 연구<br/>
    <i class="fa-li fa fa-check"></i>GAN을 이용한 자동차 영상 생성 및 변환에 대한 연구<br/>
    <i class="fa-li fa fa-check"></i>딥러닝을 이용한 영상인식 엔진 개발<br/>
    <i class="fa-li fa fa-check"></i>자연어 대화 처리를 위한 기반 기술 연구<br/>
    <i class="fa-li fa fa-check"></i>딥러닝 오픈소스 프레임워크 WICWIU 구현`,
    email: "ijkim@handong.edu",
    web: "deephandong.github.io"
  },
  {
    id: "section05",
    name: "Image Lab",
    professor: "김호준 교수님",
    backgroundColor: "white",
    posterUrl: "assets/img/lab-poster/image.jpg",
    content: `저희 S-Lab은 영상처리와 인공지능 기술에 관한 연구를 수행합니다.<br/>
    세부적으로 의료영상 처리, 딥러닝 기법, 응용 소프트웨어 개발 등의 주제를 다루며 이에 대한 기반 지식을 공부하고<br/>
    논문 연구, 시스템 개발 연구, 산학협력프로젝트, 공학프로젝트기획 및 캡스톤연구를 수행하고 있습니다.`,
    projects: `<i class="fa-li fa fa-check"></i>딥러닝을 이용한 의료영상처리 소프트웨어 개발<br/>
    <i class="fa-li fa fa-check"></i>X-ray 영상 왜곡, 결함 개선 연구`,
    email: "hjkim@handong.edu",
    web: ""
  },
  {
    id: "section06",
    name: "ISE Lab",
    professor: "남재창 교수님",
    backgroundColor: "#6399cf",
    posterUrl: "assets/img/lab-poster/ise.jpg",
    content: `ISEL(Intelligent Software Engineering Lab)에서는 소프트웨어 공학의 다양한 문제들, 특히 디버깅 활동과 관련된 문제들을 해결하는데 관심이 많습니다.<br/>
    소프트웨어 개발자를 돕고 그 결과로 안전하고 신뢰도가 높은 소프트웨어가 출시될 수 있다면, 다양한 소프트웨어 제품과 서비스를 사용하는 모든 사람들을 본질적으로 도울 것이라 기대하고 있습니다.<br/>
    주요 접근 방법은 AI(Artificial Intelligence, 인공 지능) 및 MSR(Mining Software Repositories, 소프트웨어 저장소 채굴)이며, AI와 MSR의 기법을 활용하여 GitHub등의 소프트웨어 저장소에서 수집한 데이터를 이용, 결함을 예측하거나 검출하는 연구를 주로 하고 있습니다.<br/>
    또, 수집한 데이터를 면밀히 분석하여 개발자들을 도울 수 있는 새롭고 다양한 응용 도구들의 설계와 구현에 모든 연구원들이 창의력과 역량을 발휘하고 있습니다.`,
    projects: `<i class="fa-li fa fa-check"></i>생성적 적대 신경망을 이용한 소프트웨어 결함 예측 성능 향상<br/>
    <i class="fa-li fa fa-check"></i>호환성 좋은 경량 다국어 성경앱 개발 (Lifove Bible)<br/>
    <i class="fa-li fa fa-check"></i>개발자 프로파일 기반의 소프트웨어 결함 예측<br/>
    <i class="fa-li fa fa-check"></i>PMD 버그검출 오탐지 자동 개선 알고리즘 개발`,
    email: "jcnam@handong.edu",
    web: ""
  },
  {
    id: "section07",
    name: "MI Lab",
    professor: "최희열 교수님",
    posterUrl: "assets/img/lab-poster/mi.jpg",
    backgroundColor: "#dde4ec",
    content: `MI Lab에는 지도 교수님이신 최희열 교수님과, 4명의 대학원생 그리고 10명의 학부생들이 함께 소속되어 있습니다.<br/>
    대학원생들은 Deep learning와 Reinforcement Learning에 관련된 다양한 연구 주제들을 가지고 함께 연구하고 있고 또한 교수님께서 진행하고 계신 여러 과제들에 함께 참여하고 있습니다.<br/>
    학부생들은 주로 Deep learning 관련 캡스톤 또는 공학 프로젝트 기획을 진행하고 있는 학생들과 Deep Learning과 머신러닝에 관심을 가지고 S-Lab으로 참여하는 학생들도 있습니다.`,
    projects: `<i class="fa-li fa fa-check"></i>딥러닝의 학습 기술에 대한 새로운 해석<br/>
    <i class="fa-li fa fa-check"></i>인공지능 기반 가상 네트워크 관리기술 개발<br/>
    <i class="fa-li fa fa-check"></i>VADAS 자율주행/자율주차 강화학습 모델 개발<br/>
    <i class="fa-li fa fa-check"></i>대화데이터를 이용한 인공지능 대화 모델 개발`,
    email: "hchoi@handong.edu",
    web: ""
  },
  {
    id: "section08",
    name: "MMIC Lab",
    professor: "김영식 교수님",
    backgroundColor: "#345db2",
    posterUrl: "assets/img/lab-poster/mmic.jpg",
    content: `MMIC Lab(Monolithic Microwave Integrated Circuit Laboratory)은 유/무선 통신에 활용되는 고속·저전력 회로에 대한 연구를 하는 곳입니다.<br/>
    아날로그·디지털·RF등 여러 분야에 대한 회로를 설계하고 제작하며, 제작된 칩들을 테스트하는 다양한 장비들을 갖추고 있습니다.<br/>
    김영식 교수님의 지도 아래 4명의 대학원생과 8명의 학부생이 소속되어 있으며, 뉴턴홀 317호에 연구실이 있습니다.`,
    projects: `<i class="fa-li fa fa-check"></i>Wakeup Receiver 및 Analog to Digital Converter Chip Design<br/>
    <i class="fa-li fa fa-check"></i>다중 카메라 인터페이스 개발<br/>
    <i class="fa-li fa fa-check"></i>자율주행을 위한 영상인식 및 주행 제어 플렛폼 개발<br/>
    <i class="fa-li fa fa-check"></i>해양 관측 레이더용 데이터 수집 및 처리 장치 개발<br/>
    <i class="fa-li fa fa-check"></i>Adaptive Echo-canceling Headphone Design<br/>
    <i class="fa-li fa fa-check"></i>Pipeline Inspection Robot`,
    email: "young@handong.edu",
    web: ""
  },
  {
    id: "section09",
    name: "스마트카 랩",
    professor: "이강, 황성수, 김영식 교수님",
    backgroundColor: "white",
    posterUrl: "assets/img/lab-poster/110.jpg",
    content: `이강,황성수,김영식 교수님이 지도해주시는 자율주행-머신러닝 랩입니다.<br/>
    저희는 1/10 전기자동차를 이용한 자율주행을 연구하고 있습니다.<br/>
    ROS환경에서 영상정보를 기반으로 차선인식, 차량인식, 보행자인식 등을 영상 처리나 머신 러닝을 통해 정보를 판단하여 원활한 자율주행을 할 수 있도록 속도및 조향을 제어하는 것을 목표로 합니다.<br/>
    그 외 Ridar 같은 센서를 이용한 제어도 목표로 하고 있습니다.
    연구를 통해 성능을 개선하여 자율주행 자동차 대회 우승을 목표로 하고 있습니다.`,
    projects: `<i class="fa-li fa fa-check"></i>머신러닝을 통한 다양한 object인식 및 제어<br/>
    <i class="fa-li fa fa-check"></i>차선 변경 알고리즘 개발<br/>
    <i class="fa-li fa fa-check"></i>다양한 환경 변수로부터 제어 및 주행 최적화`,
    email: "yk@handong.edu",
    web: ""
  },
  {
    id: "section10",
    name: "SW Factory Lab",
    professor: "조성배 교수님",
    backgroundColor: "#629acf",
    posterUrl: "assets/img/lab-poster/swfactory.jpg",
    content: `저희 랩은 조성배 교수님의 지도 하에 학업과 연구를 바탕으로 창업 아이디어를 아이템하거나, 서비스 상용화 혹은 실제 창업을 목표로 도전하는 사람들이 모여 함께 공부하는 랩 입니다.<br/>
    현재 모바일 앱 개발, ml kit를 활용한 서비스 개발, 게임 개발 등 여러 분야에 관하여 공부하고, 개발을 진행하는 중입니다.<br/>
    저희 랩은 본인이 가지고 있는 아이디어를 공유, 검토하고 개발을 희망 하는 학생들로 이루어져있습니다.`,
    projects: `<i class="fa-li fa fa-check"></i>소셜 Running 앱<br/>
    <i class="fa-li fa fa-check"></i>여행자 그룹 매핑 서비스<br/>
    <i class="fa-li fa fa-check"></i>(주) 허그인 스마트폰 어플리케이션 개발<br/>
    <i class="fa-li fa fa-check"></i>사운드 기반 게임 플랫폼<br/>
    <i class="fa-li fa fa-check"></i>Tensorflow.js 기반 동작인식 크롬 플러그인<br/>
    <i class="fa-li fa fa-check"></i>얼굴인식을 통한 외모추상화 채팅 서비스<br/>
    <i class="fa-li fa fa-check"></i>명화/만화 화풍 이미지 변환 서비스<br/>
    <i class="fa-li fa fa-check"></i>반려동물 레시피 어플리케이션<br/>
    <i class="fa-li fa fa-check"></i>티켓 리셀링 플랫폼 개발<br/>
    <i class="fa-li fa fa-check"></i>GPS 기반 이미지 소셜 서비스`,
    email: "sungbaejo@handong.edu",
    web: ""
  },
  {
    id: "section11",
    name: "WA Lab",
    professor: "김광 & 장소연 교수님",
    backgroundColor: "#dde4ec",
    posterUrl: "assets/img/lab-poster/walab.jpg",
    content: `WA Lab은 Web And App의 줄임말 입니다.<br/>
    저희 S-Lab은 Web&App개발 연구를 주로 진행하고 있으며<br/>사물인터넷, 무선통신등을 활용한 다양한 Web&App 개발 방법에 관심을 가지고 있습니다.`,
    projects: `<i class="fa-li fa fa-check"></i>PMS 모니터링 시스템<br/>
    <i class="fa-li fa fa-check"></i>미팅 예약서비스 어플리케이션 개발<br/>
    <i class="fa-li fa fa-check"></i>여행정보 제공 서비스<br/>
    <i class="fa-li fa fa-check"></i>인터넷 방송 앱 개발`,
    email: "kkim@handong.edu",
    web: ""
  },

]
